function sendEmail(event) {
  event.preventDefault();

  const data = {
    size: document.getElementById("size").value,
    quantity: document.getElementById("quantity").value,
    email: document.getElementById("email").value,
  };

  emailjs.send("service_wl4ds5h", "template_k1bzkqo", data)
    .then(() => {
      alert("Success");
      document.getElementById("buyForm").reset();
    })
    .catch((error) => {
      alert("Failed: " + error);
    });
}
